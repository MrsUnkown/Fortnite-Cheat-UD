probaly best public source rn fell free to paste and sell ;) (still ud)
